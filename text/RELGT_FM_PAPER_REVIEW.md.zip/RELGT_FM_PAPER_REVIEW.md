# From RelGT to a Relational Graph Foundation Model

## Paper review, design decisions, and experimental roadmap

**Review date:** 2026-08-17

**RelGT repository snapshot reviewed:** commit [19e423c](https://github.com/snap-stanford/relgt/commit/19e423ca3e7cac761130aba790857f2dc3a46ef7)

**Scope:** papers and public project material available through 2026-08-17

---

## Executive conclusion

The strongest path is **not** to take the current RelGT model and simply pretrain it on more databases. RelGT is a strong task-specific temporal graph backbone, but a relational graph foundation model also needs:

1. **Schema-equivariant inputs:** no learned table-specific encoders, fixed type IDs, or database-sized state.
2. **An explicit task and adaptation interface:** task tokens plus optional labeled support examples, with honest separation of zero-label inference from in-context learning.
3. **A label-aware ICL mechanism:** graph encoding alone does not reliably infer a new target from sparse labels.
4. **A relational pretraining distribution:** diverse synthetic databases followed by carefully curated real databases and tasks.
5. **A curriculum:** progress from single-table distributions to simple joins, temporal motifs, complex schemas, and long contexts.
6. **Cross-database evaluation:** leave-database, leave-domain, and leave-task-out tests under matched label, context, and compute budgets.

The recommended model is a **two-pass Support-Conditioned RelGT Foundation Model**:

- **Pass A:** a label-free, schema-equivariant graph encoder preserves column identity and computes structural representations.
- **Pass B:** support labels condition lightweight graph adapters and a batch-level tabular ICL head, allowing the model to identify task-relevant columns, paths, and examples without rebuilding the whole backbone.

This resolves an important tension in the literature:

- RDBLearn shows that task-agnostic horizontal compression across heterogeneous columns can destroy the information an ICL decoder needs.
- KumoRFM-2 shows that row-level alignment and early task information are necessary for interactions that fixed column-wise aggregation cannot express.
- OpenRFM and TabICL show that a separate batch-level ICL stage is critical when labeled relational cells are sparse.

The core research hypothesis should therefore be:

> **Can a graph-native, column-preserving first pass plus a support-conditioned second pass outperform both fixed relational flattening and end-to-end cell transformers on unseen databases?**

That is a stronger and more defensible contribution than “a larger RelGT.”

---

## 1. What counts as a relational graph foundation model?

A model should satisfy the following contract before we call it a foundation model.

### Generalization axes

The same pretrained checkpoint should accept:

- an unseen database;
- an unseen schema and table count;
- unseen table, column, and foreign-key names;
- unseen feature distributions and class vocabularies;
- an unseen prediction target;
- optionally, a small labeled support set for the new task.

### Adaptation regimes

Results should be reported separately for:

1. **Zero-label / zero-shot:** no target-task labels and no target-task weight updates.
2. **Frozen ICL:** target-task support labels are supplied, but weights remain frozen.
3. **Linear probe:** a small head is trained on frozen representations.
4. **Parameter-efficient adaptation:** adapters or LoRA are trained.
5. **Full fine-tuning:** all weights can change.

“No gradient updates” is not enough to call a result zero-shot when target-task labels are present in the context. That setting is ICL.

### Task coverage

The long-term target should include:

- binary and multiclass classification;
- regression;
- temporal forecasting;
- cell autocomplete / imputation;
- link prediction and recommendation;
- eventually multi-target or multi-task queries.

### Safety and correctness constraints

The model must preserve:

- timestamp cutoffs at the row, edge, support, and retrieval levels;
- permutation symmetry over rows, columns, and tables where order is semantically arbitrary;
- strict support/query separation;
- database-level isolation and contamination auditing.

---

## 2. What RelGT already contributes

RelGT has several ingredients worth retaining.

- It represents a relational database as a temporal heterogeneous graph rather than requiring manual joins.
- Its tokenization includes feature, node type, hop, relative time, and local structural signals.
- Its local transformer can model interactions among nodes in a sampled subgraph.
- Its global centroid mechanism is an attempt to expose information beyond the local neighborhood.
- Its sampling and fixed-size token batches make the architecture more scalable than all-cell attention.

These are useful **graph-backbone properties**. They do not yet provide schema transfer, task prompting, ICL, or multi-database pretraining.

### Foundation-model blockers in the current code

| Current mechanism | Why it blocks foundation transfer | Required replacement |
|---|---|---|
| Per-node-type TorchFrame models in [encoders.py](https://github.com/snap-stanford/relgt/blob/19e423ca3e7cac761130aba790857f2dc3a46ef7/encoders.py#L169) | The module structure and statistics are rebuilt for each database schema | Shared datatype encoders plus schema metadata and column tokens |
| Learned database-specific node-type IDs | New tables have no stable correspondence to pretrained IDs | Schema-derived table embeddings and dynamic relation roles |
| Dataset-sized centroid assignment buffer c_idx in [model.py](https://github.com/snap-stanford/relgt/blob/19e423ca3e7cac761130aba790857f2dc3a46ef7/model.py#L64-L66) | State is tied to every node in one database and cannot transfer cleanly | Episode-local or database-local memory slots computed from current context |
| Fixed supervised MLP head in [model.py](https://github.com/snap-stanford/relgt/blob/19e423ca3e7cac761130aba790857f2dc3a46ef7/model.py#L257-L263) | Output dimensionality and semantics are task-specific | Label prototypes, class tokens, and a universal numeric decoder |
| Training stage restricted to finetune in [main_node_ddp.py](https://github.com/snap-stanford/relgt/blob/19e423ca3e7cac761130aba790857f2dc3a46ef7/main_node_ddp.py#L78) | There is no pretraining or episodic support/query loop | Multi-database masked and episodic objectives |
| Fixed K, mostly one/two-hop random neighbor context | The context is not selected for the current query or support set | Temporal, role-aware, task-aware retrieval with explicit budgets |
| No task-table or support-label representation | The frozen model cannot know what new target function it is being asked to implement | Task tokens, support labels, label masks, and query tokens |

### Engineering prerequisites before scaling

These are not paper-level design choices, but they should be fixed before spending on pretraining:

- Sampling results are stored by node ID only, so multiple examples for the same entity at different cutoff times can overwrite one another.
- The global fallback can sample rows from after the seed timestamp.
- Sampling with replacement creates duplicate nodes, while the local node map collapses duplicates when building edges.
- the scaled dot-product attention path passes a nonzero dropout probability even during evaluation.
- random GNN positional features make repeated evaluation stochastic unless controlled.
- vector-quantizer EMA and centroid assignments need explicit distributed synchronization.

The foundation-model refactor should treat each sample as **(database, task, entity, cutoff time, support episode)**, never just a node ID.

---

## 3. Paper-by-paper review

### Priority legend

- **Adopt:** implement in the first serious prototype.
- **Adapt:** use the principle, but change its implementation for graph-native RelGT.
- **Baseline:** reproduce or compare against it.
- **Defer:** useful later, but not required to validate the central hypothesis.

### 3.1 KumoRFM-2: Scaling Foundation Models for Relational Learning

**Status:** April 2026 preprint; commercial model and SDK.

**Primary source:** [arXiv:2604.12596](https://arxiv.org/abs/2604.12596)

#### What the paper contributes

KumoRFM-2 is the closest public description of the desired end system. It reasons at four scales:

1. cells within a row;
2. rows within a table;
3. rows connected through primary/foreign-key relations;
4. labeled examples across the support batch.

It uses alternating column/row attention to build task-conditioned row embeddings, graph attention across foreign keys, and cross-sample attention for ICL. Target information is injected early. Context selection combines local history for the prediction entity with recent global examples, and it supports lagged labels. Pretraining progresses from single-table to relational data and mixes synthetic with real databases.

Across the paper's 41 tasks, the strongest message is not one exact score but the robustness pattern: performance improves with more support examples, relational hops, and context, while task-conditioned feature selection is more resistant to irrelevant columns and missing links than the previous version.

#### What to borrow

- **Adopt:** the decomposition into within-row, within-table, foreign-key, and cross-sample computation.
- **Adopt:** support labels as a first-class input rather than an afterthought.
- **Adopt:** local entity history plus global recent supports.
- **Adopt:** progressive single-table to relational pretraining.
- **Adapt:** early task conditioning through a two-pass architecture, so task information can guide selection without leaking query labels.
- **Baseline:** context-width, hop-depth, feature-noise, link-drop, and cold-start robustness curves.

#### What not to inherit uncritically

- The paper gives a high-level architecture but does not disclose enough model-size, corpus, and optimization detail for independent reconstruction.
- The weights and full training pipeline are not open, so the reported recipe cannot be isolated cleanly.
- Injecting targets early demands precise masks. An apparent gain can otherwise be label leakage or temporal leakage.
- A 10k-example context is operationally different from a 16-, 32-, or 128-label few-shot setting; results must be plotted against actual label count and coverage.

#### RelGT experiment

Compare:

1. label-free RelGT encoding plus a late ICL head;
2. labels injected into the full backbone;
3. the proposed two-pass support-conditioned adapters.

Use identical support sets and enforce that query tokens cannot expose their labels.

---

### 3.2 Relational Transformer (RT)

**Status:** ICLR 2026.

**Primary sources:** [arXiv:2510.06377](https://arxiv.org/abs/2510.06377), [OpenReview](https://openreview.net/forum?id=rpPtgMC5s9)

#### What the paper contributes

RT treats each cell as a token containing value, column, and table semantics. A task is represented as another relational table. It constructs a bounded, time-filtered BFS context and alternates sparse relational attention patterns:

- same-column attention;
- within-row feature attention;
- parent/child relational attention;
- optional full attention.

The same masked-cell objective is used for pretraining and downstream prediction. It omits ordinary positional embeddings, helping preserve table, row, and column permutation invariance.

Its ablations are especially useful:

- same-column attention is crucial for transfer;
- schema names contribute;
- unrestricted full attention contributes least and can hurt;
- historical labels for the same target entity are the dominant driver of the reported zero-shot transfer.

#### What to borrow

- **Adopt:** task representation in the same input vocabulary as the database.
- **Adopt:** schema text plus shared datatype value encoders.
- **Adopt:** sparse relational attention masks rather than unrestricted all-pairs attention.
- **Adopt:** a pretraining objective whose interface matches downstream prediction.
- **Adapt:** use cell/column slots inside RelGT row tokens instead of making every database cell a global token.

#### Critical interpretation

RT defines zero-shot as no weight updates, but its context can contain past labels from task rows. The paper's own ablation shows that same-entity historical labels dominate transfer. Our evaluation must split:

- no target labels anywhere;
- lagged labels for the query entity;
- labels from other entities;
- ordinary K-shot supports;
- combinations of the above.

Without this separation, “zero-shot” and “few-shot” comparisons are not interpretable.

#### RelGT experiment

Replace RelGT's single compressed row feature with a small set of column-preserving latent slots and compare RT-style masks to ordinary local self-attention under equal token budgets.

---

### 3.3 RT-J: Large-Scale Pretraining Unlocks Few-Shot Prediction for Relational Data

**Status:** 2026 preprint/project release.

**Primary source:** [official RT-J project page](https://star-project.stanford.edu/rt-j/)

#### What it adds beyond RT

RT-J scales RT-style pretraining to THE JOIN: roughly 650 real databases and about 6,000 tasks, with RelBench overlap removed. It uses variable context lengths, multi-cell masking, random-walk retrieval, and explicit future-row masking. The public description reports an 85M-parameter model trained on 32 H100s and evaluates contexts up to 8,192 cells.

The important result for us is that **data/task diversity plus retrieval** converts an architecture result into much stronger few-shot behavior. Schema-name shuffling still hurts, showing that semantic metadata is useful rather than cosmetic.

#### What to borrow

- **Adopt:** database- and task-level deduplication between pretraining and evaluation.
- **Adopt:** variable context lengths and multiple masked targets per context.
- **Adapt:** random-walk retrieval into a temporal, relation-role-aware sampler.
- **Adopt:** large task diversity, not merely many rows from a few databases.
- **Baseline:** context-length and support-size scaling curves.

#### Limitation

The public evidence is concentrated on forecasting over 21 RelBench tasks, with an 8,192-cell context limit. Link prediction and broader database reasoning remain open.

---

### 3.4 OpenRFM: Dissecting Relational In-Context Learning

**Status:** June 2026 preprint.

**Primary source:** [arXiv:2606.04320](https://arxiv.org/abs/2606.04320)

#### What the paper contributes

OpenRFM provides the most useful diagnosis of why an RT-like model can underperform as an ICL system.

1. **Model-side diagnosis:** sparse label-bearing cells make relation-level attention resemble an underdetermined kernel regression problem.
2. **Data-side diagnosis:** a synthetic generator can yield low pretraining loss while teaching a lazy or nearly frozen feature regime. The synthetic task must contain a support-identifiable latent signal.

Its solution combines:

- a relational backbone;
- a batch-level ICL module adapted from TabICL;
- a normalization/adapter bridge;
- homophily-aware synthetic tasks;
- continued real-data pretraining;
- prototype-based regularization.

The largest architectural gain comes from the extra batch-level ICL stage. A fully entangled 2D attention design can optimize pretraining loss yet collapse downstream, while a simpler detached bridge is more stable.

#### What to borrow

- **Adopt:** a separate cross-example ICL head after graph encoding.
- **Adopt:** careful normalization between the graph and ICL representation spaces.
- **Adopt:** support-identifiable and homophily/heterophily-controlled synthetic labels.
- **Adopt:** prototype representations for variable class vocabularies.
- **Adopt:** support-selection and ensemble ablations.
- **Defer:** deeply interleaving graph and ICL layers until the detached version is established.

#### RelGT experiment

Train the graph encoder first with relational self-supervision, attach a frozen or lightly adapted TabICL head, and compare:

- detached graph embeddings;
- end-to-end joint training;
- alternating graph/ICL blocks.

Do not select the design using pretraining loss alone; select on held-out databases.

---

### 3.5 TabICL

**Status:** ICML 2025.

**Primary source:** [arXiv:2502.05564](https://arxiv.org/abs/2502.05564)

#### What the paper contributes

TabICL separates tabular reasoning into:

1. column-wise distribution modeling across examples;
2. row-wise integration across features;
3. dataset-wise support/query reasoning, where labels are introduced.

This hierarchy scales ICL beyond the small contexts of early PFNs. It also demonstrates that curriculum over rows, columns, and classes is essential.

#### What to borrow

- **Adopt:** the final support/query transformer as the first RelGT-FM ICL head.
- **Adopt:** label masking in which support examples can communicate but queries cannot reveal labels.
- **Adapt:** feed multiple column-preserving graph slots rather than one fixed row vector.
- **Adopt:** curriculum over context length and task complexity.

#### Limitation

The original paper focuses on classification, and its position treatment is not perfectly column-permutation invariant. Large support batches remain expensive. We should treat TabICL as a component and baseline, not as proof that graph structure has been solved.

---

### 3.6 No Need to Train Your RDB Foundation Model (RDBLearn / JUICE)

**Status:** ICML 2026.

**Primary sources:** [arXiv:2602.13697](https://arxiv.org/abs/2602.13697), [OpenReview](https://openreview.net/forum?id=hrtEiSftwk)

#### What the paper contributes

RDBLearn makes a strong information-preservation argument. Before seeing the target labels, a fixed relational encoder does not know which heterogeneous columns will matter. Compressing horizontally across columns can therefore increase sample complexity or erase the useful signal. It recommends compressing vertically within semantically shared column/path units and delaying task-dependent combination until the ICL decoder sees labels.

JUICE implements this with parameter-free SQL-style features indexed by column and meta-path, then applies a strong tabular ICL decoder. This is a formidable baseline because it avoids training a relational encoder entirely.

#### What to borrow

- **Adopt:** preserve column and path identity until support labels are available.
- **Adopt:** JUICE or equivalent SQL/DFS features as a mandatory baseline.
- **Adapt:** add these aggregates as an optional side channel to RelGT, not as its only representation.
- **Adopt:** analyze irrelevant-column sample complexity, not only average accuracy.

#### What it does not settle

Fixed per-column aggregates cannot express every relational function. KumoRFM-2 gives a simple counterexample: a label may depend on two attributes co-occurring in the same child row even when all individual column marginals are identical. Static aggregation also loses exact topology, temporal motifs, cycles, and row identities.

#### RelGT design resolution

Use **multiple row latents keyed by column or column group**. Perform graph message passing without collapsing them to one task-agnostic vector. Let support-conditioned adapters decide how to mix columns and row interactions in Pass B.

---

### 3.7 RDB-PFN

**Status:** March 2026 preprint.

**Primary source:** [arXiv:2603.03805](https://arxiv.org/abs/2603.03805)

#### What the paper contributes

RDB-PFN shows that a compact model pretrained on a well-matched relational prior can be competitive without a large graph backbone. It:

- generates synthetic schemas, foreign-key structures, and content with structural causal models;
- flattens one- and two-hop neighborhoods with DFS-style aggregations;
- presents 64–1,024 labeled examples as a PFN episode;
- predicts a query in one frozen forward pass.

The model is small—roughly 0.7M parameters in the paper—yet strong on its 19-task binary-classification evaluation. This is evidence that **the prior and episodic objective may matter more than parameter count** during the first stage of RFM development.

#### What to borrow

- **Adopt:** episodic support/query pretraining.
- **Adopt:** a compact pilot before scaling RelGT.
- **Adopt:** matched synthetic priors and explicit support-count curricula.
- **Baseline:** RDB-PFN and DFS plus a strong tabular FM under equal labels.

#### What not to inherit as the core

DFS linearization discards exact row topology, cycles, repeated relational roles, and many temporal patterns. It also binds the model to an aggregation library. RDB-PFN's reported task scope is primarily binary classification; broad regression, multiclass, recommendation, and link prediction remain unresolved.

The fair scientific comparison is **native RelGT subgraphs versus DFS-linearized contexts under equal label, token, and compute budgets**.

---

### 3.8 PluRel: Synthetic Data Unlocks Scaling Laws for RFMs

**Status:** ICML 2026.

**Primary source:** [arXiv:2602.04029](https://arxiv.org/abs/2602.04029)

#### What the paper contributes

PluRel is the best starting point for a relational synthetic-data engine. It samples:

1. a schema graph;
2. row-level foreign-key connectivity;
3. table features through structural causal models, including temporal sources.

It reports power-law behavior in masked pretraining loss as the number of synthetic databases and tokens increase. More diverse synthetic data improves unseen-real-database results, and synthetic pretraining followed by real-data continuation can outperform real-only continuation.

#### What to borrow

- **Adopt:** the three-stage schema, connectivity, and feature generator.
- **Adopt:** controlled distributions over topology, cardinality, causal structure, and time.
- **Adopt:** synthetic-to-real continuation as one curriculum arm.
- **Adopt:** downstream scaling curves, not just pretraining loss curves.

#### Extensions required for our model

The initial PluRel generator is too clean and narrow. Add:

- cyclic schemas and self-referential foreign keys;
- bridge tables and many-to-many relations;
- multiple foreign keys between the same table pair with different semantic roles;
- missing values, corrupted keys, skewed cardinalities, and heavy-tailed degrees;
- text and high-cardinality categoricals;
- temporal drift, delayed effects, seasonality, and censoring;
- homophily, heterophily, anti-correlation, and support-unidentifiable controls;
- binary, multiclass, regression, link, and recommendation targets;
- task scarcity and class imbalance.

Masked loss scaling is not sufficient evidence of foundation transfer. Every scaling run must include held-out-database downstream curves.

---

### 3.9 Curriculum Matters and PluRel-to-RDB-PFN

**Status:** July 2026 preprints; Curriculum Matters is a short workshop-style study.

**Primary sources:** [Curriculum Matters, arXiv:2607.29120](https://arxiv.org/abs/2607.29120), [PluRel-to-RDB-PFN, arXiv:2607.29129](https://arxiv.org/abs/2607.29129)

#### What these papers contribute

Curriculum Matters reports that progressively widening single-table tasks from 7 to 17 columns dramatically outperforms presenting the same type of data all at once. It also finds that a relatively small relational curriculum recovers much of RDB-PFN's reported result, and that single-table pretraining can perform surprisingly well after relational flattening.

PluRel-to-RDB-PFN reports that starting with more realistic schema-guided data and then broadening to diverse synthetic schemas can outperform the reverse ordering at far lower data scale.

#### What to borrow

- **Adopt:** explicit easy-to-hard curricula over width, rows, joins, topology, time, and support count.
- **Adopt:** report number of databases, tasks, rows, tokens, and compute separately.
- **Adapt:** test curriculum order as a factorial experiment.

#### Caution

These are very recent results and partly conflict with the synthetic-first continuation result in PluRel. They use a particular DFS/PFN pipeline, so they do not prove that relational structure is unnecessary. The correct lesson is that **order matters enough to measure**, not that one universal order is established.

---

### 3.10 Griffin

**Status:** ICML 2025 workshop paper / 2025 preprint.

**Primary source:** [arXiv:2505.05568](https://arxiv.org/abs/2505.05568)

#### What the paper contributes

Griffin provides a useful supervised-transfer architecture:

- frozen text encoders for categorical/text values and schema metadata;
- quantile-normalized numeric values with pretrained float encoder/decoder;
- task-conditioned cross-attention to pool variable row features;
- relation-wise aggregation before cross-relation aggregation, reducing domination by frequent edge types;
- masked single-table completion followed by supervised single-table and relational fine-tuning.

Its transfer studies show that diversity helps, but domain similarity matters and negative transfer occurs.

#### What to borrow

- **Adopt:** reusable datatype encoders and universal decoders.
- **Adapt:** task-conditioned row pooling into the proposed second pass.
- **Adopt:** relation-balanced aggregation so high-degree or common foreign-key types do not dominate.
- **Adopt:** similarity-aware pretraining sampling or mixture-of-experts routing.

#### Limitation

The strongest configuration uses downstream fine-tuning and multiple supervised checkpoints. Griffin is evidence for transfer, not a clean frozen-ICL solution. Encoding all categories as text may also be brittle for opaque enterprise IDs.

---

### 3.11 RELATE

**Status:** NeurIPS 2025 workshop paper.

**Primary source:** [arXiv:2510.19954](https://arxiv.org/abs/2510.19954)

#### What the paper contributes

RELATE is a low-risk blueprint for replacing RelGT's per-table TorchFrame ModuleDict. It uses shared modality encoders for numeric, timestamp, categorical, and text fields; column metadata; and Perceiver-style latent queries to produce fixed-size row embeddings independent of column order.

It achieves broadly competitive RelBench results with fewer parameters, although some tasks show meaningful losses.

#### What to borrow

- **Adopt:** shared modality-specific value encoders.
- **Adopt:** column metadata and a schema-agnostic row encoder.
- **Adapt:** output multiple latent slots rather than a single row vector, preserving information for ICL.

#### Limitation

RELATE demonstrates encoder replacement within task-specific training, not multi-database pretraining or frozen transfer. It solves the input module problem, not the entire RFM problem.

---

### 3.12 GraphPFN

**Status:** ICML 2026.

**Primary source:** [arXiv:2509.21489](https://arxiv.org/abs/2509.21489)

#### What the paper contributes

GraphPFN starts from a pretrained tabular PFN and inserts sparse one-hop graph-attention adapters into every transformer block. Its synthetic prior combines stochastic block structures, preferential attachment, and graph-aware causal mechanisms. It shows that graph adapters can reuse strong tabular representations, and adapter-only tuning can approach full tuning.

#### What to borrow

- **Baseline:** a pretrained tabular FM with lightweight graph adapters.
- **Adapt:** compare “RelGT then TabICL” with “TabICL blocks interleaved with RelGT adapters.”
- **Adopt:** adapter-only tuning as an efficient adaptation regime.
- **Adopt:** graph-aware causal mechanisms in the synthetic generator.

#### Limitation

GraphPFN studies mostly homogeneous, static, whole-graph node tasks. It does not directly solve arbitrary relational schemas, temporal cutoffs, or foreign-key semantics.

---

### 3.13 G2T-FM

**Status:** 2025–2026 preprint, revised June 2026.

**Primary source:** [arXiv:2508.20906](https://arxiv.org/abs/2508.20906)

#### What the paper contributes

G2T-FM augments node tables with:

- neighborhood feature aggregation;
- degree, PageRank, and Laplacian eigenvectors;
- learned structural encodings such as PEARL;
- a strong tabular FM for ICL or fine-tuning.

It is a reminder that a simple graph-to-table bridge can outperform nominal GFMs. The paper also correctly distinguishes labeled-context ICL from zero-shot learning.

#### What to borrow

- **Baseline:** cheap structural features plus TabPFN/TabICL/LimiX.
- **Adapt:** use deterministic structural summaries as an auxiliary RelGT input.
- **Adopt:** report the incremental value of learned graph reasoning over good preprocessing.

#### Limitation

The approach is not relational-database-aware: relation roles, multi-table semantics, and temporal cutoffs need additional handling. Handcrafted summaries should remain a baseline or side channel, not the defining architecture.

---

### 3.14 ULTRA

**Status:** ICLR 2024.

**Primary source:** [arXiv:2310.04562](https://arxiv.org/abs/2310.04562)

#### What the paper contributes

ULTRA addresses a problem directly analogous to unseen database schemas: relation vocabularies differ across graphs. Instead of learning a fixed embedding per relation, it builds a **relation graph** whose nodes are relation types and whose edges encode four reusable interaction motifs: head-to-head, head-to-tail, tail-to-head, and tail-to-tail. A query-conditioned GNN generates relation representations dynamically.

#### What to borrow

- **Adopt:** dynamic foreign-key relation embeddings instead of fixed relation IDs.
- **Adapt:** build a schema-level interaction graph over foreign-key roles and directions.
- **Add metadata:** table/column names, cardinality, optionality, timestamp role, and bridge-table motifs.
- **Defer:** full ULTRA-style link reasoning until node/cell tasks work.

This is the cleanest answer to “how does the model represent a relation type it has never seen?”

---

### 3.15 Billion-Scale Graph Foundation Models / GraphBFF

**Status:** February 2026 preprint.

**Primary source:** [arXiv:2602.04768](https://arxiv.org/abs/2602.04768)

#### What the paper contributes

GraphBFF is more relevant for systems and scale than for task prompting. Its transformer combines:

- **type-conditioned attention**, normalized separately within selected edge-type groups;
- **type-agnostic attention**, shared across types with fixed-degree sampling.

It uses masked link prediction, KL-based storage batching to maintain representative type distributions, and round-robin supervision over relation types. The paper reports scaling laws for a 1.4B-parameter model trained on one billion supervision edges from a very large enterprise graph.

#### What to borrow

- **Adopt:** separate type-conditioned and type-agnostic paths.
- **Adopt:** relation-balanced sampling and supervision for rare foreign-key roles.
- **Adopt:** storage-level and GPU-level batch composition metrics.
- **Adopt:** masked link prediction as one auxiliary objective.
- **Adapt:** scaling-law accounting to include sampled subgraph size, not only examples and parameters.

#### Limitation

Its evidence is from one private enterprise graph universe, and masked link prediction is the only pretraining objective. Frozen probing is not the same as task-conditioned ICL on new relational targets. We should borrow the scale recipe after validating our task prior at small scale.

---

### 3.16 Ramba

**Status:** ICML 2026.

**Primary sources:** [official project page](https://www.yunhaiwang.net/icml2026/RelMamba_index.html), [OpenReview](https://openreview.net/forum?id=s6B4ARyBLN)

#### What the paper contributes

Ramba replaces quadratic global cell attention with a selective state-space model over a column-first serialization. Schema dynamic gating uses semantic alignment between each attribute and the target to control what the state retains. Sparse entity and foreign-key attention restores explicit topology.

Its reported ablations favor:

- column-wise rather than row-wise serialization;
- schema-conditioned rather than generic gating;
- width-limited, foreign-key-prioritized BFS;
- longer context at substantially better throughput than RT.

#### What to borrow

- **Adapt:** use a schema-gated state-space branch for long global context.
- **Adopt:** foreign-key-prioritized, width-limited sampling as a baseline.
- **Adopt:** speed/quality Pareto curves across context sizes.

#### Recommendation

Do not replace RelGT's local graph transformer in version 1. First validate the two-pass ICL design. Add Ramba-like state-space memory when context length becomes the measured bottleneck.

---

### 3.17 RelBench v2

**Status:** DATA-FM workshop at ICLR 2026 / February 2026 preprint.

**Primary source:** [arXiv:2602.12606](https://arxiv.org/abs/2602.12606)

#### What the paper contributes

RelBench v2 expands RelBench to 11 native datasets, adding four databases with more than 22M rows across 29 tables. It adds autocomplete tasks, more forecasting and recommendation tasks, conversions from the Temporal Graph Benchmark, a bridge to 70+ ReDeLEx databases, and 4DBInfer datasets/tasks.

#### What to borrow

- **Adopt:** autocomplete as a natural masked-cell pretraining/evaluation bridge.
- **Adopt:** forecasting, autocomplete, and recommendation as separate task families.
- **Adopt:** temporal cutoffs and leakage-safe sampling.
- **Adopt:** ReDeLEx databases as a real-data pool after license and contamination review.
- **Adopt:** TGB conversions for temporal link tasks.

#### Limitation

RelBench v2 is a benchmark ecosystem, not yet a complete foundation-model protocol. We still need explicit database-out, domain-out, task-out, label-budget, and adaptation-regime splits.

---

### 3.18 Additional emerging results

These papers are useful but should not drive the first architecture.

| Work | Useful lesson | Recommended use |
|---|---|---|
| [Task Scarcity and Label Leakage in Relational Transfer Learning](https://openreview.net/forum?id=nI2nsMMHXp), ICLR 2026 workshop | Too few targets per database encourages task-specific shortcuts and weak cross-task transfer | Balance tasks per database; measure task-out transfer; add representation leakage probes |
| [Rel-MOSS](https://openreview.net/forum?id=f4k0XsOlCZ), ICML 2026 | Relational class imbalance requires structure-aware minority handling | Add skewed priors, PR-AUC, and minority calibration; consider later sampling modules |
| [Towards Foundation Models for RDBs with LMs and GNNs](https://arxiv.org/abs/2605.16085), 2026 preprint | Row-language encoders plus GNNs are a simple low-resource hybrid | Keep as an LM+GNN baseline, not the main design |

---

## 4. Cross-paper synthesis: what we should actually build

~~~mermaid
flowchart LR
    A["Unseen database: schema, values, FK graph, timestamps"] --> B["Universal cell and schema tokenizer"]
    Q["Task specification and query cutoff"] --> B
    B --> C["Pass A: label-free, column-preserving RelGT"]
    C --> D["Support and query graph representations"]
    S["Support labels only"] --> E["Task prototypes and support-conditioned adapters"]
    D --> E
    E --> F["Pass B: batch-level ICL transformer"]
    F --> G["Universal class, numeric, cell, or link decoder"]
    M["Episode-local memory and task-aware retrieval"] --> C
    M --> F
~~~

The query label is absent from both passes. Pass A can be cached across tasks that share a database snapshot; Pass B is the lightweight task-specific computation.

### 4.1 Universal schema and value tokenizer

For every cell, construct:

- a shared datatype value embedding;
- column-name and table-name semantics;
- missingness and observed/masked state;
- a normalized or rank-based numeric representation;
- timestamp decomposition and relative time;
- optional distribution summaries computed only from allowed training/context rows.

Recommended implementations:

- numeric: quantile/rank encoding plus a continuous value encoder;
- categorical: hashed/value embedding, with text semantics when values are meaningful words;
- text: frozen small text encoder initially;
- timestamp: absolute, cyclic, and query-relative components;
- schema: frozen text embedding plus structural role metadata.

Do **not** learn one module per table or a persistent embedding per database-specific type.

### 4.2 Column-preserving row representation

Use 4–16 latent slots per row rather than compressing the whole row immediately. Each slot attends to cell tokens and retains column identity through keys or routing tags. A single seed token can be produced for compatibility with the current RelGT head, but the graph backbone should retain the latent set.

This combines:

- RT's cell semantics;
- RELATE's schema-agnostic latent pooling;
- Griffin's task-conditioned feature selection;
- RDBLearn's warning against premature horizontal compression.

### 4.3 Dynamic relation and schema encoder

For each foreign-key role, encode:

- source table and column;
- target table and key;
- direction;
- cardinality and degree statistics;
- optionality/null rate;
- timestamp relationship;
- semantic name;
- whether it is a self-link, bridge-table role, or repeated role between the same tables.

Build a small schema/relation graph and generate relation embeddings dynamically, following ULTRA's principle. These embeddings should parameterize attention bias, gating, or adapters—not index a fixed relation embedding table.

### 4.4 Temporal and task-aware context construction

Use three context pools:

1. **Local structural context:** temporal BFS or random walk around the query entity.
2. **Entity history:** earlier snapshots and lagged labels for the same entity, reported as a distinct supervision source.
3. **Global support context:** labeled examples selected by recency, class balance, structural similarity, and query similarity.

Hard requirements:

- exclude all rows and edges after the query cutoff;
- key caches by database, task, entity, and cutoff time;
- record why each row entered the context;
- never pad with arbitrary future or unrelated rows;
- use explicit padding/mask tokens instead of duplicate real nodes;
- vary context size during training.

Retrieval is part of the model. Report sampler ablations and retrieval latency.

### 4.5 Two-pass RelGT backbone

#### Pass A: label-free structural encoding

- Encode column-preserving row latents.
- Run local relational attention over the sampled temporal graph.
- Use type-conditioned and type-agnostic attention paths.
- Apply explicit edge-role and direction biases.
- Produce query and support representations without target labels.

#### Pass B: support-conditioned adaptation

- Encode support labels as class/value tokens.
- Compute task prototypes and a task representation.
- Use small FiLM, gating, or LoRA-style adapters to reweight columns, relations, and paths.
- Optionally rerun a few light graph layers rather than the full backbone.
- Send support and query representations to a TabICL-style batch transformer.

This design allows early **task information** without giving the query its answer. It also makes an ablation between label-free, early-label, and two-pass conditioning straightforward.

### 4.6 Replace persistent centroids with transferable memory

The current c_idx centroid assignment should not survive into the foundation model. Test:

- episode-local memory slots pooled from the current support/query context;
- database-local schema/table summary slots;
- retrieval-based global examples;
- a Ramba-like state-space summary for very long contexts.

Memory must be recomputed from the current database and task, not tied to global node IDs learned during pretraining.

### 4.7 Universal output interface

- **Binary/multiclass:** label tokens or support-derived class prototypes; no fixed output dimension.
- **Regression:** normalized numeric token plus distributional or quantile decoder; return uncertainty.
- **Autocomplete:** masked cell decoder selected by datatype.
- **Link/recommendation:** relation-conditioned pair decoder with retrieval-aware negatives.

---

## 5. Pretraining objectives

The primary objective should be **episodic query prediction**, because that exactly matches frozen ICL. Add self-supervised objectives to improve representations, not replace the episodic objective.

| Objective | Purpose | Leakage control |
|---|---|---|
| Episodic support/query prediction | Learn a new target function from examples | Query label always masked; directional support/query attention |
| Masked cell modeling | Universal value and schema semantics | Mask correlated target proxies together |
| Masked foreign-key/link prediction | Relation and topology understanding | Remove the supervised edge from the input graph |
| Temporal next-event or time-gap prediction | Temporal dynamics | Strict cutoff and censoring rules |
| Path/motif prediction | Multi-hop structural reasoning | Construct negatives matched for degree and type |
| Column/table/row permutation consistency | Enforce database symmetries | Apply paired augmentations with identical labels |
| Schema-name dropout/shuffle contrast | Measure reliance on semantics versus structure | Shuffle only in dedicated robustness batches |
| Prototype regularization | Stable variable-class ICL | Derive prototypes from supports only |

Objective sampling must be balanced across databases, tables, relation types, modalities, and task families. Otherwise large tables and common edge types will dominate.

---

## 6. Data and curriculum

### 6.1 Synthetic generator

Start from PluRel's schema → connectivity → SCM design, then add the extensions listed in Section 3.8. Every generated task should carry metadata describing:

- its causal signal path;
- shortest useful hop;
- whether the label is identifiable from the support set;
- homophily/heterophily level;
- degree and cardinality regime;
- temporal lag and drift;
- noise, missingness, and imbalance;
- whether fixed DFS features are theoretically sufficient.

This metadata enables targeted curriculum and mechanistic evaluation.

### 6.2 Real pretraining pool

Candidate sources:

- RelBench v1/v2;
- ReDeLEx;
- 4DBInfer;
- TGB-to-RelBench conversions;
- public SQL/database repositories with compatible licenses;
- THE JOIN if access and licensing permit.

For every source, record:

- license and permitted model-training use;
- entity/table provenance;
- overlap or near-duplicate relationships with evaluation databases;
- task construction logic;
- timestamp availability and leakage risks.

Split by database before generating examples. Never let rows or tasks from an evaluation database leak into pretraining through a different benchmark wrapper.

### 6.3 Recommended curriculum

| Phase | Data/tasks | Goal |
|---|---|---|
| 0 | Narrow single tables, few columns/classes | Stabilize datatype encoders and ICL |
| 1 | Wider single tables with distractor columns | Learn column selection and irrelevant-feature robustness |
| 2 | One-hop star schemas and simple SCMs | Learn FK roles and relation aggregation |
| 3 | Two/multi-hop schemas, bridge tables, row co-occurrence targets | Distinguish graph-native reasoning from fixed aggregates |
| 4 | Temporal schemas, drift, lagged labels, censoring | Learn leakage-safe forecasting |
| 5 | Mixed synthetic plus real databases | Close the synthetic-real distribution gap |
| 6 | Long context, rare relations, imbalance, link/recommendation | Stress scalability and broaden task coverage |

Run at least three controlled curriculum orders:

1. synthetic simple → synthetic complex → real;
2. real-like schemas → diverse synthetic → real continuation;
3. shuffled all-at-once.

Hold total tasks, tokens, and optimizer updates constant.

---

## 7. Evaluation protocol

### 7.1 Splits

Report:

- leave-database-out;
- leave-domain-out;
- leave-schema-family-out;
- leave-task-out within a known database;
- future-time test;
- cold-start entities;
- unseen relation roles;
- synthetic-to-real and real-to-real transfer.

### 7.2 Label and context budgets

At minimum evaluate:

- 0 labels;
- 8, 32, 128, 512, and 1,024 support labels;
- full-data fine-tuning.

For every result, report:

- number of support labels;
- number of cells/rows/nodes/edges in context;
- hop depth;
- inference FLOPs or wall time;
- ensemble count;
- whether lagged same-entity labels are available.

### 7.3 Required baselines

1. Current RelGT trained from scratch.
2. GraphSAGE/HGT/RelGNN task-specific models.
3. LightGBM/CatBoost on target-table features.
4. DFS or JUICE plus LightGBM.
5. DFS or JUICE plus TabPFN/TabICL/LimiX.
6. RDB-PFN.
7. RT or the strongest reproducible RT checkpoint.
8. Griffin where its adaptation regime matches.
9. G2T-FM-style structural features plus a tabular FM.
10. RelGT representations plus a linear probe.
11. RelGT plus the batch ICL head.
12. The full two-pass support-conditioned model.

KumoRFM-2 can be reported as an external reference, but it cannot replace reproducible baselines.

### 7.4 Metrics

- classification: AUROC, average precision, log loss, calibration error;
- multiclass: macro/micro F1, log loss, top-k accuracy or MRR where appropriate;
- regression: MAE, normalized MAE, R², calibration/coverage;
- link/recommendation: MRR, Hits@k, MAP@k with explicit negative protocol;
- systems: latency, peak memory, tokens/second, preprocessing time, and database I/O.

Use per-task tables, mean rank, confidence intervals, and win/tie/loss counts. A normalized average alone can hide catastrophic failures.

### 7.5 “Zero-shot” reporting template

Every table should contain explicit columns:

- weight updates: none / adapter / full;
- target labels in context: none / other entities / same-entity history / ordinary support;
- number of labels;
- evaluation database seen in pretraining: yes/no;
- task seen in pretraining: yes/no;
- schema seen in pretraining: yes/no.

---

## 8. Highest-information experiments

These experiments should precede large-scale pretraining.

| ID | Question | Comparison | Decision signal |
|---|---|---|---|
| E1 | Can RelGT become schema-agnostic without losing task-specific accuracy? | Current per-table encoder vs shared RELATE-like multi-slot encoder | Similar in-domain score plus successful unseen-schema execution |
| E2 | Does an explicit ICL head matter? | Linear head vs TabICL head on frozen graph embeddings | Consistent database-out gains at 8–512 labels |
| E3 | When should labels enter? | Late-only vs full early injection vs two-pass adapters | Two-pass wins without leakage and is robust to label sparsity |
| E4 | Is graph-native reasoning worth it? | JUICE/DFS vs native RelGT under equal labels/tokens/compute | Gains on row co-occurrence, exact topology, temporal, and multi-hop tasks |
| E5 | What replaces c_idx? | Persistent centroids vs episode memory vs retrieved supports vs no global path | Transfer gains without database-sized state |
| E6 | How should unseen relations be encoded? | Fixed role IDs vs schema text vs ULTRA-style dynamic relation graph | Better unseen-role and schema-out transfer |
| E7 | What context should be retrieved? | BFS, random walk, recent, balanced, query-aware, hybrid | Best quality/latency frontier and stable temporal correctness |
| E8 | Which pretraining distribution works? | Synthetic-only, real-only, synthetic→real, real-like→diverse→real | Held-out-database score, not pretraining loss |
| E9 | Does curriculum order matter for RelGT? | Progressive vs shuffled under equal tokens | Downstream transfer and optimization stability |
| E10 | Is long-context architecture needed? | Transformer memory vs Ramba-like state-space branch | Add only if context length is the measured bottleneck |

### Synthetic capability tests

Include diagnostic tasks whose answer requires:

- two features co-occurring in the same child row;
- a particular ordered relation path;
- counting distinct related entities;
- distinguishing two foreign keys with different roles;
- a temporal lag or event order;
- a cycle or self-reference;
- heterophilous support-label propagation;
- ignoring many correlated distractor columns.

Because the true generating process is known, these tests reveal what each representation destroys.

---

## 9. Phased implementation roadmap

### Phase 0: correctness and episode abstraction

- Fix time-aware sample identity and leakage.
- Make evaluation deterministic.
- Remove database-sized training state from the model API.
- Define an Episode object containing database, schema, task, support rows, query rows, cutoffs, graph context, and masks.
- Add unit tests for support/query and temporal isolation.

**Gate:** identical samples reproduce identical outputs; adversarial future rows cannot affect predictions.

### Phase 1: minimum viable RelGT-FM

- Implement shared datatype encoders.
- Implement schema/table/column metadata tokens.
- Produce multiple column-preserving row latents.
- Add task tokens and label masks.
- Add a detached TabICL-style support/query head.
- Train on small synthetic single-table and one-hop relational episodes.

**Gate:** one checkpoint runs on an unseen schema with no new modules and beats RelGT plus a newly trained head in low-label transfer.

### Phase 2: graph-native support conditioning

- Add dynamic relation embeddings from a schema relation graph.
- Add support-conditioned lightweight graph adapters.
- Replace c_idx with episode memory or retrieval.
- Add temporal and task-aware support retrieval.
- Train on row-co-occurrence and multi-hop synthetic diagnostics.

**Gate:** the model beats JUICE/DFS plus TabICL on tasks that require preserved topology while matching it on aggregation-friendly tasks.

### Phase 3: real-data continuation and curriculum

- Pretrain across deduplicated public databases.
- Compare curriculum orders under equal compute.
- Balance databases, tasks, relation types, and modalities.
- Evaluate leave-database and leave-domain-out on RelBench v2/4DBInfer.

**Gate:** positive transfer is broad rather than concentrated in databases similar to pretraining sources.

### Phase 4: scale and task breadth

- Add long-context state-space memory if E10 supports it.
- Add link/recommendation episodes and masked-link pretraining.
- Add distributed type-balanced batching.
- Fit model/data/context scaling curves.

**Gate:** scaling improves held-out tasks predictably, not only masked pretraining loss.

---

## 10. Go/no-go criteria

Before scaling beyond a compact model, require all of the following:

1. The same checkpoint accepts a completely unseen database without creating learned per-table modules.
2. Frozen ICL improves monotonically, on average, from 8 to 512 support labels.
3. The graph-native model beats a parameter-free JUICE/DFS plus tabular-FM baseline on predeclared structure-dependent tasks.
4. It does not materially underperform that baseline on aggregation-friendly tasks.
5. Two-pass task conditioning beats or matches early full-label injection under strict leakage tests.
6. Database-out gains survive removal of schema names and same-entity historical labels, even if performance decreases.
7. Synthetic scaling predicts held-out real performance better than pretraining loss alone.
8. All reported gains survive equalization of labels, context tokens, ensemble count, and inference compute.

If criterion 3 fails, the project should pivot toward a relational retrieval/aggregation front end for a strong tabular FM rather than scaling a graph transformer.

---

## 11. Proposed paper contribution

A coherent research paper could claim:

### Support-Conditioned, Schema-Equivariant RelGT

1. **A column-preserving universal row tokenizer** that transfers across arbitrary database schemas.
2. **A dynamic foreign-key relation graph** that parameterizes unseen relation roles without fixed IDs.
3. **A two-pass graph-plus-batch ICL architecture** that reconciles task-agnostic information preservation with label-conditioned relational reasoning.
4. **A diagnostic relational prior** spanning tasks where fixed aggregation is sufficient and tasks where it is provably insufficient.
5. **A strict cross-database evaluation protocol** separating zero-label, lagged-label, ICL, probing, and fine-tuning regimes.

The most interesting scientific result would not be a single average rank. It would be a map of **when learned graph reasoning adds value beyond a strong parameter-free relational encoder and tabular foundation model**.

---

## 12. Decision table

| Idea | Source | Decision | RelGT-FM implementation |
|---|---|---|---|
| Task table / task tokens | RT | Adopt | Task, target column, horizon, and query tokens |
| Shared cell and schema encoders | RT, Griffin, RELATE | Adopt | Universal modality encoders; no per-table ModuleDict |
| Preserve column identity before labels | RDBLearn | Adopt | Multiple column-keyed row latents |
| Row-level cross-column interactions | KumoRFM-2 | Adopt | Lightweight within-row attention before/after task conditioning |
| Separate batch ICL stage | OpenRFM, TabICL, KumoRFM-2 | Adopt | Support/query transformer after graph encoder |
| Dynamic relation vocabulary | ULTRA | Adapt | Schema relation graph and FK-role-conditioned adapters |
| Sparse relational attention masks | RT | Adapt | Edge-role, direction, row, column, and neighborhood masks |
| Relation-balanced aggregation/batching | Griffin, GraphBFF | Adopt | Per-relation normalization and round-robin task sampling |
| Episodic PFN training | RDB-PFN | Adopt | Synthetic support/query episodes |
| PluRel generator | PluRel | Adopt and extend | Cycles, roles, text, time, missingness, imbalance |
| Curriculum over complexity | TabICL, Curriculum Matters | Adopt | Single-table → relational → temporal → long context |
| Fixed DFS/JUICE aggregates | RDBLearn, RDB-PFN | Baseline and side channel | Mandatory comparator; optional auxiliary features |
| Graph adapters in a tabular FM | GraphPFN | Baseline | Competing architecture to RelGT→TabICL |
| Handcrafted structural features | G2T-FM | Baseline | Degree/PageRank/NFA/PE as low-cost comparison |
| Persistent node-centroid assignments | Current RelGT | Reject | Episode-local memory or retrieval |
| Unrestricted all-cell attention | RT ablations, OpenRFM | Defer/reject for v1 | Structured sparse attention only |
| Long-context state-space branch | Ramba | Defer pending bottleneck | Schema-gated global memory |
| Billion-parameter scaling first | GraphBFF | Reject as first move | Validate prior and objective with compact models |

---

## References

### Direct relational foundation-model papers

1. Dwivedi et al. [Relational Graph Transformer](https://arxiv.org/abs/2505.10960), ICLR 2026.
2. Ranjan et al. [Relational Transformer: Toward Zero-Shot Foundation Models for Relational Data](https://arxiv.org/abs/2510.06377), ICLR 2026.
3. Stanford STAR. [RT-J: Large-Scale Pretraining Unlocks Few-Shot Prediction for Relational Data](https://star-project.stanford.edu/rt-j/), 2026.
4. Hudovernik et al. [KumoRFM-2: Scaling Foundation Models for Relational Learning](https://arxiv.org/abs/2604.12596), 2026.
5. Chen et al. [OpenRFM: Dissecting Relational In-Context Learning](https://arxiv.org/abs/2606.04320), 2026.
6. Xu et al. [No Need to Train Your RDB Foundation Model](https://arxiv.org/abs/2602.13697), ICML 2026.
7. Wang et al. [Relational In-Context Learning via Synthetic Pre-training with Structural Prior / RDB-PFN](https://arxiv.org/abs/2603.03805), 2026.
8. Kothapalli et al. [PluRel: Synthetic Data Unlocks Scaling Laws for Relational Foundation Models](https://arxiv.org/abs/2602.04029), ICML 2026.
9. Abolhasani and Ganapathy. [Curriculum Matters](https://arxiv.org/abs/2607.29120), 2026.
10. Abolhasani and Ganapathy. [From PluRel to RDB-PFN](https://arxiv.org/abs/2607.29129), 2026.
11. Wang et al. [Griffin: Towards a Graph-Centric Relational Database Foundation Model](https://arxiv.org/abs/2505.05568), 2025.
12. Meyer et al. [RELATE: A Schema-Agnostic Perceiver Encoder for Multimodal Relational Graphs](https://arxiv.org/abs/2510.19954), 2025.

### Enabling graph/tabular foundation-model papers

13. Qu et al. [TabICL: A Tabular Foundation Model for In-Context Learning on Large Data](https://arxiv.org/abs/2502.05564), ICML 2025.
14. Zhang et al. [GraphPFN: A Prior-Data Fitted Graph Foundation Model](https://arxiv.org/abs/2509.21489), ICML 2026.
15. Eremeev et al. [Turning Tabular Foundation Models into Graph Foundation Models / G2T-FM](https://arxiv.org/abs/2508.20906), 2025/2026.
16. Galkin et al. [Towards Foundation Models for Knowledge Graph Reasoning / ULTRA](https://arxiv.org/abs/2310.04562), ICLR 2024.
17. Bechler-Speicher et al. [Billion-Scale Graph Foundation Models / GraphBFF](https://arxiv.org/abs/2602.04768), 2026.
18. Liu et al. [Ramba: Selective State-Space Models for Relational Deep Learning](https://www.yunhaiwang.net/icml2026/RelMamba_index.html), ICML 2026.

### Benchmark and diagnostic papers

19. Gu et al. [RelBench v2](https://arxiv.org/abs/2602.12606), 2026.
20. Azevedo et al. [Task Scarcity and Label Leakage in Relational Transfer Learning](https://openreview.net/forum?id=nI2nsMMHXp), ICLR 2026 workshop.
21. Yin et al. [Rel-MOSS](https://openreview.net/forum?id=f4k0XsOlCZ), ICML 2026.

---

## Bottom line

Build a **schema-equivariant, graph-native encoder that preserves column and row structure**, then make it a foundation model through **episodic support/query pretraining, a label-aware batch ICL stage, dynamic relation representations, and diverse relational curricula**.

The first decisive milestone is not a billion-parameter checkpoint. It is a compact model that, on unseen databases and matched support budgets:

- beats current RelGT in frozen low-label transfer;
- beats JUICE/DFS plus TabICL on structure-dependent tasks;
- matches strong tabular baselines on aggregation-friendly tasks;
- remains temporally correct and reproducible.

Only after that should model, data, and context scaling begin.
