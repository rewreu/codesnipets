# UCGP project summary

Last updated: August 19, 2026  
Evidence through: August 18, 2026  
Source meetings: 1 design meeting and 1 operations review

## Project at a glance

UCGP is building a graph-centered customer platform intended to support richer customer relationships, identity/entity resolution, permissions, and digital experiences than the current RAD/Customer Core environment. The near-term program is focused on delivering a controlled November milestone for the Bank Family CX use case while establishing foundational capabilities that future use cases can reuse.

The first release is intentionally conservative. The existing RAD real-time matching logic should be reproduced in UCGP behind a cleaner service interface, without changing the model's decision tree or calculations. This reduces model-governance risk and makes it possible to compare UCGP results with the current system.

The project is not only a model migration. It includes data synchronization, graph data modeling and migration, equivalency and reconciliation, monitoring, risky-merge review, API/service implementation, stakeholder governance, testing, and launch readiness.

## Business objective

Create a reusable customer graph and service platform that can:

- Represent customers, accounts, roles, permissions, and relationships with richer context.
- Support Bank Family CX and later cross-domain customer experiences.
- Make reliable real-time matching and identity decisions.
- Synchronize safely with current systems during migration.
- Demonstrate that new UCGP behavior is at least equivalent to the existing RAD implementation.
- Eventually reduce dependence on overnight batch processing and legacy architecture.

## Near-term MVP

The current MVP centers on Bank Family CX and custom-permissions capabilities. Its expected components are:

1. A bounded set of customer journeys and required data services.
2. A UCGP real-time matching service using the same logic and calculations as RAD.
3. A defined minimum viable data contract for the first use case.
4. Synchronization between RAD/Customer Core and UCGP in every direction required by the use case.
5. Reconciliation and equivalency checks proving that synchronized data and model decisions are trustworthy.
6. Batch processing that remains the final decision authority during the initial phase.
7. Monitoring for model behavior, input quality, volumes, edge cases, and human-review outcomes.
8. Human review of risky merges through CDOP where equivalent controls are required.
9. A graph and secondary-storage design capable of handling current scale and future growth.

BCMP, Bookkeeper, Lightweight Login, Trilogy, MDU, marketing, and other engagements were discussed but were not all equally committed or defined. Their inclusion in the November MVP requires explicit confirmation.

## Target operating flow

The working near-term flow is:

```text
Bank/customer input
        ↓
UCGP APIs and input preparation
        ↓
UCGP real-time matching service
        ↓
Immediate decision and customer experience
        ↓
Synchronization into the existing Bank/RAD batch path
        ↓
Batch decision remains final authority
        ↓
Real-time/batch comparison, monitoring, and risky-merge review
```

This flow is transitional. The long-term direction is to make UCGP's real-time decisions more precise and authoritative, reducing the amount of work deferred to batch. The monitoring framework must change when batch is no longer the ground truth.

## Current workstreams and status

| Workstream | Current state | Summary |
|---|---|---|
| Bank Family CX MVP | Yellow | Scope, exclusions, customer narrative, and required data services need final agreement and architecture sign-off. |
| Delivery planning | Yellow | High-level dates exist, but work must be decomposed into small deliverables with owners, dependencies, dates, sizes, and exit criteria. |
| Model service | In progress | The November implementation should reproduce existing RAD logic behind a UCGP service wrapper. Team ownership and complexity estimates need confirmation. |
| Equivalency and monitoring | In progress | Core metrics are identified, but baselines, thresholds, statistical treatment, cadence, and operational ownership remain open. |
| CDC/data synchronization | Watch | The POV is complete and POCs are planned. Both synchronization directions must be explicitly mapped to use cases. |
| Real-time synchronization | Red/blocking | The integration team is blocked on the final CDC, RAD-timeline, or hybrid design. |
| Data migration | Yellow | Migration is coupled to ongoing synchronization and graph-storage decisions. |
| Graph architecture and capacity | Material risk | Object count, storage boundaries, load/restore time, resilience, and one-versus-multiple graph instances require empirical validation. |
| Business-risk engagement | Reported on track | Ownership and forum participation are being clarified. Specific concerns should be routed through named leads. |
| CDOP/risky-merge controls | Open | Integration scope and real-time-versus-batch case reconciliation are not yet defined. |
| Production-like testing | Open | RAD beta access, DFS priority, cost, and the possibility of a smaller environment require a decision. |
| Stakeholder governance | In progress | A registry, engagement catalog, integrated roadmap, cross-functional group, and executive steering forums are being established. |

## Milestones

### September 30, 2026 — QA planning target

The operations review described September 30 as the date communicated to Bank for a system ready to test in QA. Some flexibility may exist because Bank integration work is not expected to begin until Q4.

### November 15, 2026 — platform/production milestone

November 15 was presented as the main production-readiness milestone, with the original plan allowing roughly six weeks between QA and production hardening.

The meaning of the November milestone needs explicit reconciliation:

- The operations meeting stated that the November milestone had no users attached and that the friends-and-family pilot remained below roughly 200 users.
- The design meeting contained language suggesting that users or Bank/front-book cases might begin entering the system in November.

Until the program confirms whether November is platform-only, pilot expansion, or a user-facing launch, schedule and risk discussions may continue to use inconsistent assumptions.

## Definition of success

### Functional equivalence

- UCGP uses the same real-time matching decision tree and calculations as RAD for the MVP.
- The rate at which batch changes a real-time decision is comparable with the existing RAD baseline.
- Known differences are explainable by population, inputs, or deliberately approved architecture changes.

### Data integrity

- Required fields arrive complete and correctly formatted through the new API path.
- RAD-to-UCGP and UCGP-to-RAD synchronization requirements are explicit.
- Reconciliation demonstrates that synchronized records are complete, current, and internally consistent.

### Model and control performance

- Real-time/batch change rate is monitored alongside risky-merge review, reviewer disagreement, merge/split volume stability, and segmented edge cases.
- Low launch volume is handled with an agreed statistical method and minimum sample rules.
- Risky merges are routed to CDOP when required, with a defined case lifecycle and review SLA.

### Operational readiness

- MVP scope and exclusions are approved.
- Every critical deliverable has an accountable owner, date, dependency list, and exit criterion.
- QA and hardening time are sufficient for the agreed November outcome.
- Monitoring production, review, escalation, and post-launch ownership are assigned.

### Technical viability

- The synchronization design is approved and integrated.
- Graph-engine 1.5 load testing supports the projected data volume and growth.
- Graph, secondary-storage, and partition boundaries are documented.
- External AWS dependencies have committed dates or credible mitigations.

## Established decisions and direction

1. Preserve the existing RAD matching logic for the first UCGP release.
2. Use batch as the final decision authority during the initial phase.
3. Use real-time-versus-batch change rate as a core equivalency metric, but not the only metric.
4. Treat reconciliation and equivalency as foundational parts of synchronization.
5. Define synchronization direction and minimum data requirements per use case.
6. Continue independent platform work in parallel rather than serializing the entire program behind sync.
7. Validate graph scale empirically before committing the final storage architecture.
8. Treat any temporary legacy feed as an explicit time-to-market exception with an exit plan.
9. Organize delivery into approximately one-to-two-week increments with individual ownership and exit criteria.
10. Separate business-risk approval status from technical and delivery risks.

## Principal risks

- MVP boundaries and the meaning of the November milestone are not fully aligned.
- The real-time synchronization team is already blocked.
- Reverse synchronization may be under-scoped for some use cases.
- Identical model logic can still produce different results if inputs are missing or transformed.
- Initial UCGP volume may be too small for naive percentage comparisons.
- Graph scale may exceed a practical single-instance design.
- AWS engine and strong-consistency timelines are not committed.
- Temporary legacy paths could become permanent architecture without an explicit exit plan.
- CDOP integration and model-monitoring ownership remain unresolved.
- Partner-team members may have divided attention rather than dedicated capacity.

## Immediate priorities

1. Finalize the Bank Family CX MVP PRD, exclusions, and required data services.
2. Confirm what the November milestone actually launches and whether users are attached.
3. Publish a credible workback schedule from QA through production hardening.
4. Complete sync POCs and choose the CDC/timeline/hybrid design.
5. Define the minimum viable data contract and both synchronization directions.
6. Confirm the Bank-to-batch flow for UCGP-originated users.
7. Complete the equivalency framework: baseline, thresholds, sample-size method, cadence, owners, and escalation.
8. Confirm model-service teams, complexity, and delivery dates.
9. Run graph-engine 1.5 capacity tests and decide graph versus secondary storage.
10. Scope CDOP integration and case reconciliation.

Detailed ownership and meeting-source links are maintained in the [open action register](./indexes/OPEN-ACTIONS.md).

## Governance and documentation

The project is establishing:

- A cross-functional working group.
- Dedicated cross-domain product and engineering participation.
- VP/MVP-level and EVP-level steering forums.
- A stakeholder registry and engagement catalog.
- An integrated roadmap linking engagements, use cases, capabilities, owners, dates, and dependencies.

The engagement site is intended to visualize agreed information, not replace authoritative source systems such as the project repository and JIRA.

## Source documents

- [Meeting index](./indexes/MEETINGS.md)
- [Cross-meeting summary](./indexes/CROSS-MEETING-SUMMARY.md)
- [Open action register](./indexes/OPEN-ACTIONS.md)
- [UCGP Design 1 summary](./meetings/design/2026/2026-08-18-ucgp-design-01/summary.md)
- [UCGP Design 1 detailed notes](./meetings/design/2026/2026-08-18-ucgp-design-01/notes.md)
- [UCGP Operations Review 1 summary](./meetings/operations/2026/2026-08-18-ucgp-ops-01/summary.md)

## Evidence caveat

This summary is based on two machine-transcribed meetings whose transcripts have not yet been formally reviewed. Proper names, acronyms, figures, and conflicting schedule statements should be verified against the recordings, meeting decks, and authoritative project documents before formal distribution.
